<template>
  <div class="app-shell">
    <header class="topbar">
      <div>
        <nav class="nav-links" aria-label="页面导航">
          <a class="btn" href="/">课程资源</a>
          <a class="btn" href="/replay">课程回放</a>
        </nav>
        <h1>如何同步课件与课堂</h1>
        <p>课程回放通常会分别下载教师画面、课件画面或学生画面。把这些视频放在同一个播放器网格中同步播放，就能比较自然地还原课堂。</p>
      </div>
      <nav class="nav-links" aria-label="外部链接">
        <a class="btn primary" href="https://github.com/vzhd1701/gridplayer" target="_blank" rel="noreferrer">GridPlayer 官网</a>
      </nav>
    </header>

    <main id="main" class="page-grid">
      <section class="panel pad">
        <div class="section-title" style="margin-bottom: 1rem">
          <span class="step">1</span>
          <h2>下载 GridPlayer</h2>
        </div>
        <p class="guide-text">
          GridPlayer 是一个免费开源的多视频播放器，支持把多个视频放在网格中同时播放。课程回放下载出的教师画面、课件画面和其他画面，可以一起拖入 GridPlayer。
        </p>
        <a class="btn primary" href="https://github.com/vzhd1701/gridplayer" target="_blank" rel="noreferrer">前往 GridPlayer 项目页</a>
      </section>

      <section class="panel pad">
        <div class="section-title" style="margin-bottom: 1rem">
          <span class="step">2</span>
          <h2>同步播放</h2>
        </div>
        <p class="guide-text">
          下载同一节课的多个画面后，打开 GridPlayer，将这些视频拖入同一个播放窗口。开始播放后，你可以同时查看课堂实录和课件内容。
        </p>
      </section>

      <section class="panel pad">
        <div class="section-title" style="margin-bottom: 1rem">
          <span class="step">3</span>
          <h2>文件命名建议</h2>
        </div>
        <p class="guide-text">
          在课程回放页的全局参数中，可以选择按日期或课程顺序命名。保持同一课时的文件名前缀一致，会更方便一次性拖入播放器。
        </p>
      </section>
    </main>
  </div>
</template>
